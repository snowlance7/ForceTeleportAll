Ever feel like theres too many crewmates outside? Want to get those lazy bums back to work?
Well now you can forcefully teleport them into the facility at random so they can get back to work!
Now you can focus more on getting that quota!

To run the command just type teleportall into the console. Default settings allow anyone to use the command, changeable in config file.